# TrabalhoExperimental
Repositório destinado ao trabalho da disciplina MAF 261 - Estatística Experimental
